package com.example.usc.fbsearch;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

//Implementing the interface OnTabSelectedListener to our MainActivity
//This interface would help in swiping views
public class ResultActivity extends AppCompatActivity implements TabLayout.OnTabSelectedListener{


    public static final String EXTRA_MESSAGE2 = "com.example.usc.myfirst.MESSAGE";
    private TabLayout tabLayout;
    private static String message = "";
    private String fromDetails = "";
    public static final String SWITCH_TAB = "";

    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        // Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
        message = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);
        //Toast.makeText(ResultActivity.this, "In Result"+message, Toast.LENGTH_LONG).show();

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        message = (preferences.getString("currentInput", null));
        //Toast.makeText(ResultActivity.this, "Input"+input, Toast.LENGTH_LONG).show();

        //Adding toolbar to the activity
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
            }
        });

        //Initializing the tablayout
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);

        //Adding the tabs using addTab() method
        tabLayout.addTab(tabLayout.newTab().setText("Users").setIcon(R.mipmap.users));
        tabLayout.addTab(tabLayout.newTab().setText("Pages").setIcon(R.mipmap.pages));
        tabLayout.addTab(tabLayout.newTab().setText("Events").setIcon(R.mipmap.events));
        tabLayout.addTab(tabLayout.newTab().setText("Places").setIcon(R.mipmap.places));
        tabLayout.addTab(tabLayout.newTab().setText("Groups").setIcon(R.mipmap.groups));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        //Initializing viewPager
        viewPager = (ViewPager) findViewById(R.id.pager);

        //Creating our pager adapter
        Pager adapter = new Pager(getSupportFragmentManager(), tabLayout.getTabCount());

        //Adding adapter to pager
        viewPager.setAdapter(adapter);

        //Adding onTabSelectedListener to swipe views
        tabLayout.setOnTabSelectedListener(this);
    }

    public static String getCurrentInput(){
        return message;
    }

    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        viewPager.setCurrentItem(tab.getPosition());
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {

    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }

    public void sendMessage2(View view) {
        String e = "Welcome to Details";
        Intent intent = new Intent(this, DetailsActivity.class);
        intent.putExtra(EXTRA_MESSAGE2, e);
        startActivity(intent);
    }
}
