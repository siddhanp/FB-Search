package com.example.usc.fbsearch;

import android.content.Context;
import android.content.Intent;

import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.TabLayout;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.support.v4.app.Fragment;
import android.widget.Toast;

import com.facebook.CallbackManager;
import com.facebook.FacebookSdk;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.widget.ShareDialog;


public class DetailsActivity extends AppCompatActivity implements TabLayout.OnTabSelectedListener {

    private TabLayout tabLayout;
    private static String id = "";
    private static String url = "";
    private static String name = "";
    private static String type = "";
    private static String format = "";
    CallbackManager callbackManager;
    ShareDialog shareDialog;
    private ViewPager viewPager;
    private Menu menu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);


        facebookSDKInitialize();
        callbackManager = CallbackManager.Factory.create();
        shareDialog = new ShareDialog(this);


        //Toast.makeText(this, "First Details", Toast.LENGTH_LONG).show();
        Intent intent = this.getIntent();
        type = intent.getExtras().getString("Type");
        id = intent.getExtras().getString("ID");
        url = intent.getExtras().getString("URL");
        name = intent.getExtras().getString("Name");
        format = "##"+"@"+type+"@"+id+"@"+name;
        //Toast.makeText(this, "Second Details", Toast.LENGTH_LONG).show();

        //Adding toolbar to the activity

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(getApplicationContext(), ResultActivity.class);
                startActivity(intent2);
            }
        });

        //Initializing the tablayout
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);

        //Adding the tabs using addTab() method
        tabLayout.addTab(tabLayout.newTab().setText("Albums").setIcon(R.mipmap.albums));
        tabLayout.addTab(tabLayout.newTab().setText("Posts").setIcon(R.mipmap.posts));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        //Initializing viewPager
        viewPager = (ViewPager) findViewById(R.id.pager);

        //Creating our pager adapter
        Pager2 adapter = new Pager2(getSupportFragmentManager(), tabLayout.getTabCount());

        //Adding adapter to pager
        viewPager.setAdapter(adapter);

        //Adding onTabSelectedListener to swipe views
        tabLayout.setOnTabSelectedListener(this);

    }

    protected void facebookSDKInitialize() {
        callbackManager = CallbackManager.Factory.create();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        this.menu = menu;
        getMenuInflater().inflate(R.menu.main, menu);
        boolean flag;
        flag = checkFavorites();
        if(flag)
        {
            //Toast.makeText(this, "Add!", Toast.LENGTH_LONG).show();
            menu.getItem(0).setTitle("Remove from Favorites!");
        }
        else
        {
            //Toast.makeText(this, "Remove", Toast.LENGTH_LONG).show();
            menu.getItem(0).setTitle("Add to Favorites!");
        }

        return true;
    }

    @Override
    protected void onActivityResult(final int requestCode, int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        callbackManager.onActivityResult(requestCode, resultCode, data);
        if(resultCode == -1){
            Toast.makeText(this, "You shared this post!", Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(this, "You did not share this post!", Toast.LENGTH_LONG).show();
        }
    }

    public boolean manageFavorites(){

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        if(preferences.contains(format))
        {
            SharedPreferences.Editor editor = preferences.edit();
            editor.remove(format);
            editor.apply();
            Toast.makeText(this, "Removed from Favorites!", Toast.LENGTH_LONG).show();
            return true;
        }
        else
        {
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString(format, url);
            editor.apply();
            Toast.makeText(this, "Added to Favorites!", Toast.LENGTH_LONG).show();
            return false;
        }

    }

    public boolean checkFavorites(){

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        if(preferences.contains(format))
        {
            return true;
        }
        else
        {
            return false;
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        boolean temp, flag;
        flag = checkFavorites();
        if(flag)
        {
            //Toast.makeText(this, "Add!", Toast.LENGTH_LONG).show();
            menu.getItem(0).setTitle("Remove from Favorites!");
        }
        else
        {
            //Toast.makeText(this, "Remove", Toast.LENGTH_LONG).show();
            menu.getItem(0).setTitle("Add to Favorites!");
        }

        int id1 = item.getItemId();
        if (id1 == R.id.add_to_fav)
        {

            temp = manageFavorites();
            flag = checkFavorites();
            if(flag)
            {
                //Toast.makeText(this, "Add!", Toast.LENGTH_LONG).show();
                menu.getItem(0).setTitle("Remove from Favorites!");
            }
            else
            {
                //Toast.makeText(this, "Remove", Toast.LENGTH_LONG).show();
                menu.getItem(0).setTitle("Add to Favorites!");
            }

            return true;
        }
        else if(id1 == R.id.share)
        {
            Toast.makeText(this, "Sharing "+name+"!", Toast.LENGTH_LONG).show();

            if (ShareDialog.canShow(ShareLinkContent.class)) {
                ShareLinkContent content = new ShareLinkContent.Builder()
                        .setContentUrl(Uri.parse("http://facebook.com/" + id))
                        .build();
                shareDialog.show(content);
            }

            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public static String getCurrentId(){
        return id;
    }

    public static String getCurrentName(){
        return name;
    }

    public static String getCurrentURL(){
        return url;
    }

    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        viewPager.setCurrentItem(tab.getPosition());
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {

    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }


}
