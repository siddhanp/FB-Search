package com.example.usc.fbsearch;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import java.lang.reflect.Array;
import java.util.ArrayList;


public class PostAdapter extends BaseAdapter{

    private Activity activity;
    private ArrayList time,message;
    private String name,url;
    private static LayoutInflater inflater = null;

    public PostAdapter(Activity a, ArrayList b, ArrayList bod, String name, String url) {
        activity = a;
        this.time = b;
        this.message= bod;
        this.name = name;
        this.url = url;

        inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    public int getCount() {
        return time.size();
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        if (convertView == null)
            vi = inflater.inflate(R.layout.row3, null);


        ImageView imageView = (ImageView) vi.findViewById(R.id.imgP);
        Picasso.with(activity).load(url).resize(180,180).into(imageView);

        TextView n = (TextView) vi.findViewById(R.id.nameP);
        n.setText(name);

        TextView t = (TextView) vi.findViewById(R.id.timeP);
        String ctime = time.get(position).toString();
        String[] parts = ctime.split("\\+");
        String part = parts[0];
        ctime = part.replace("T", "  ");
        t.setText(ctime);

        TextView m = (TextView) vi.findViewById(R.id.messageP);
        String msg = message.get(position).toString();
        m.setText(msg);


        return vi;

    }}