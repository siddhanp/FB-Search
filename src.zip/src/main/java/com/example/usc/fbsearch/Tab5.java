package com.example.usc.fbsearch;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Map;


//Our class extending fragment
public class Tab5 extends Fragment {

    public static final int CONNECTION_TIMEOUT = 10000;
    public static final int READ_TIMEOUT = 15000;
    ListView list;
    BaseAdapter5 adapter;
    private Button btnNext;
    private Button btnPrev;
    ArrayList<String> display_name = new ArrayList<String>();
    ArrayList<String> display_url = new ArrayList<String>();
    ArrayList<String> display_id = new ArrayList<String>();

    ArrayList<String> name_array = new ArrayList<String>();
    ArrayList<String> url_array = new ArrayList<String>();
    ArrayList<String> id_array = new ArrayList<String>();

    //Overriden method onCreateView
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //ResultActivity god = new ResultActivity();
        //String s = god.getCurrentInput();
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
        String s = prefs.getString("currentInput", null);
        View myInflatedView = inflater.inflate(R.layout.tab5, container, false);
        btnPrev  = (Button)  myInflatedView.findViewById(R.id.userBtnPrev);
        btnNext  = (Button)  myInflatedView.findViewById(R.id.userBtnNext);



        list = (ListView) myInflatedView.findViewById(R.id.list_notice2);

        if(s!=null)
        {
            new AsyncRetrieve().execute(s, "group", "group");
        }
        else
        {
            //Toast.makeText(getActivity(),"USER FAVORITES", Toast.LENGTH_LONG).show();
            ArrayList<String> fname_array = new ArrayList<String>();
            ArrayList<String> furl_array = new ArrayList<String>();
            ArrayList<String> fid_array = new ArrayList<String>();

            Map<String, ?> allEntries = prefs.getAll();
            for (Map.Entry<String, ?> entry : allEntries.entrySet())
            {
                //Toast.makeText(getActivity(),entry.getKey() + ": " + entry.getValue().toString(), Toast.LENGTH_LONG).show();
                String key = entry.getKey();
                String value = entry.getValue().toString();
                String[] parts = key.split("@");
                String a = parts[0];
                if(a.equals("##"))
                {
                    String t = parts[1];
                    String i = parts[2];
                    String n = parts[3];
                    if(t.equals("group")) {
                        fname_array.add(n);
                        furl_array.add(value);
                        fid_array.add(i);
                        //Toast.makeText(getActivity(), t + i + n, Toast.LENGTH_LONG).show();
                        //Toast.makeText(getActivity(), value, Toast.LENGTH_LONG).show();
                    }
                }
            }

            adapter = new BaseAdapter5(getActivity(), fname_array, furl_array, fid_array);
            list.setAdapter(adapter);
        }

        return myInflatedView;
    }


    private class AsyncRetrieve extends AsyncTask<String, String, String> {

        HttpURLConnection conn;
        URL url = null;

        //this method will interact with UI, here display loading message
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        // This method does not interact with UI, You need to pass result to onPostExecute to display
        @Override
        protected String doInBackground(String... params) {
            try {
                String strURL = "http://cs-server.usc.edu:14345/sidPhp.php?ip=" + params[0] + "&type=" + params[1] + "&choice=usual";
                url = new URL(strURL);

            } catch (MalformedURLException e) {
                e.printStackTrace();
                return e.toString();
            }
            try {

                // Setup HttpURLConnection class to send and receive data from php
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(READ_TIMEOUT);
                conn.setConnectTimeout(CONNECTION_TIMEOUT);
                conn.setRequestMethod("GET");

                // setDoOutput to true as we recieve data from json file
                conn.setDoOutput(true);

            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
                return e1.toString();
            }
            try {

                int response_code = conn.getResponseCode();

                // Check if successful connection made
                if (response_code == HttpURLConnection.HTTP_OK) {

                    // Read data sent from server
                    InputStream input = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                    String line;

                    StringBuilder result = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }
                    // Pass data to onPostExecute method
                    return (result.toString());

                } else {

                    return ("unsuccessful");
                }

            } catch (IOException e) {
                e.printStackTrace();
                return e.toString();
            } finally {
                conn.disconnect();
            }

        }

        // this method will interact with UI, display result sent from doInBackground method
        @Override
        protected void onPostExecute(String result) {

            //t.setText(result);

            if (result != null) // add this
            {

                try {

                    JSONObject new_obj = new JSONObject(result);
                    JSONArray new_array = new_obj.getJSONArray("data");
                    for (int i = 0, count = new_array.length(); i < count; i++) {
                        try {

                            // Get each object in array of objects
                            JSONObject jsonObject = new_array.getJSONObject(i);

                            // Get the name of each object in "name"
                            name_array.add(jsonObject.getString("name"));
                            id_array.add(jsonObject.getString("id"));

                            // Get the URL of each object in "picture" -> "data" -> "url"
                            JSONObject pictureObject = jsonObject.getJSONObject("picture");
                            JSONObject dataObject = pictureObject.getJSONObject("data");
                            url_array.add(dataObject.getString("url"));

                        } catch (JSONException e) {
                            e.printStackTrace();

                        }
                    }

                    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putString("GroupCurrent", "zero");
                    editor.apply();
                    btnPrev.setEnabled(false);
                    Toast.makeText(getActivity(), "zero", Toast.LENGTH_LONG).show();

                    for (int i = 0; i < 10; i++) {
                        display_name.add(name_array.get(i));
                        display_id.add(id_array.get(i));
                        display_url.add(url_array.get(i));
                    }


                    adapter = new BaseAdapter5(getActivity(), display_name, display_url, display_id);
                    list.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();


                }
            }


            btnNext.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {

                    //Toast.makeText(v.getContext(), "Next Page please!", Toast.LENGTH_LONG).show();
                    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
                    String current = prefs.getString("GroupCurrent", null);
                    SharedPreferences.Editor editor = prefs.edit();
                    display_name.clear();
                    display_id.clear();
                    display_url.clear();

                    switch(current)
                    {
                        case "zero":
                            Toast.makeText(v.getContext(), "one", Toast.LENGTH_LONG).show();
                            editor.putString("GroupCurrent", "one");
                            editor.apply();
                            btnNext.setEnabled(true);
                            btnPrev.setEnabled(true);
                            int l;
                            if(name_array.size() < 20)
                            {
                                l = name_array.size();
                            }
                            else
                            {
                                l = 20;
                            }
                            for (int i = 10; i < l; i++) {
                                display_name.add(name_array.get(i));
                                display_id.add(id_array.get(i));
                                display_url.add(url_array.get(i));
                            }

                            break;

                        case "one":
                            Toast.makeText(v.getContext(), "two", Toast.LENGTH_LONG).show();
                            editor.putString("GroupCurrent", "two");
                            editor.apply();
                            btnNext.setEnabled(false);
                            btnPrev.setEnabled(true);
                            int m;
                            if(name_array.size() < 25)
                            {
                                m = name_array.size();
                            }
                            else
                            {
                                m = 25;
                            }
                            for (int i = 20; i < m; i++) {
                                display_name.add(name_array.get(i));
                                display_id.add(id_array.get(i));
                                display_url.add(url_array.get(i));
                            }
                            break;

                        case "two":
                            Toast.makeText(v.getContext(), "INVALID", Toast.LENGTH_LONG).show();
                            break;

                    }
                    adapter = new BaseAdapter5(getActivity(), display_name, display_url, display_id);
                    list.setAdapter(adapter);

                }
            });

            btnPrev.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {

                    //Toast.makeText(v.getContext(), "Previous Page please!" , Toast.LENGTH_LONG).show();
                    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
                    String current = prefs.getString("GroupCurrent", null);
                    SharedPreferences.Editor editor = prefs.edit();
                    display_name.clear();
                    display_id.clear();
                    display_url.clear();

                    switch(current)
                    {
                        case "zero":
                            Toast.makeText(v.getContext(), "INVALID", Toast.LENGTH_LONG).show();
                            break;

                        case "one":
                            Toast.makeText(v.getContext(), "zero", Toast.LENGTH_LONG).show();
                            editor.putString("GroupCurrent", "zero");
                            editor.apply();
                            btnPrev.setEnabled(false);
                            btnNext.setEnabled(true);
                            for (int i = 0; i < 9; i++) {
                                display_name.add(name_array.get(i));
                                display_id.add(id_array.get(i));
                                display_url.add(url_array.get(i));
                            }
                            break;

                        case "two":
                            Toast.makeText(v.getContext(), "one", Toast.LENGTH_LONG).show();
                            editor.putString("GroupCurrent", "one");
                            editor.apply();
                            btnPrev.setEnabled(true);
                            btnNext.setEnabled(true);
                            for (int i = 10; i < 20; i++) {
                                display_name.add(name_array.get(i));
                                display_id.add(id_array.get(i));
                                display_url.add(url_array.get(i));
                            }
                            break;
                    }
                    adapter = new BaseAdapter5(getActivity(), display_name, display_url, display_id);
                    list.setAdapter(adapter);
                }
            });




        }
    }
}