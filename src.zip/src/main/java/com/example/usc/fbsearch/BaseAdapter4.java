package com.example.usc.fbsearch;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView;


import com.squareup.picasso.Picasso;


import java.lang.reflect.Array;
import java.util.ArrayList;


public class BaseAdapter4 extends BaseAdapter{

    private Activity activity;
    private static ArrayList name,url,id;
    private static LayoutInflater inflater = null;

    public BaseAdapter4(Activity a, ArrayList b, ArrayList bod, ArrayList c) {
        activity = a;
        this.name = b;
        this.url= bod;
        this.id = c;

        inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    public int getCount() {
        return name.size();
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public boolean checkIfPreference(int p)
    {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(activity);
        String format = "##"+"@"+"place"+"@"+id.get(p).toString()+"@"+name.get(p).toString();
        if(preferences.contains(format))
        {
            return true;
        }
        else
        {
            return false;
        }

    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        boolean flag = false;
        if (convertView == null)
            vi = inflater.inflate(R.layout.row, null);


        ImageView imageView = (ImageView) vi.findViewById(R.id.imgURL);
        String u = url.get(position).toString();
        Picasso.with(activity).load(u).resize(180,180).into(imageView);

        TextView n = (TextView) vi.findViewById(R.id.title1); // title
        String song = name.get(position).toString();
        n.setText(song);


        ImageView favStar = (ImageView) vi.findViewById(R.id.imageView5);
        flag = checkIfPreference(position);
        if(flag)
        {
            favStar.setImageDrawable(ContextCompat.getDrawable(activity, R.mipmap.staron));
        }
        else
        {
            favStar.setImageDrawable(ContextCompat.getDrawable(activity, R.mipmap.staroff));
        }

        ImageView detailsArrow = (ImageView) vi.findViewById(R.id.imageView6);

        detailsArrow.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(), "Going to next "+name.get(position), Toast.LENGTH_LONG).show();
                Intent intent = new Intent(v.getContext(), DetailsActivity.class);
                intent.putExtra("ID", id.get(position).toString());
                intent.putExtra("Type", "place");
                intent.putExtra("URL", url.get(position).toString());
                intent.putExtra("Name", name.get(position).toString());
                v.getContext().startActivity(intent);
            }
        });

        return vi;

    }}