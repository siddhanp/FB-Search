package com.example.usc.fbsearch;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;


//Our class extending fragment
public class Tab7 extends Fragment {

    public static final int CONNECTION_TIMEOUT = 10000;
    public static final int READ_TIMEOUT = 15000;
    String url1 = "";
    String name = "";
    String s = "";
    ListView list;
    TextView textView;
    PostAdapter adapter;
    ArrayList<String> time_array = new ArrayList<String>();
    ArrayList<String> message_array = new ArrayList<String>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        DetailsActivity god = new DetailsActivity();
        s = god.getCurrentId();
        url1 = god.getCurrentURL();
        name = god.getCurrentName();


        View myInflatedView = inflater.inflate(R.layout.tab7, container, false);
        list = (ListView) myInflatedView.findViewById(R.id.listP);

        new Tab7.AsyncRetrieve().execute(s, "user", "user");

        return myInflatedView;
    }

    private class AsyncRetrieve extends AsyncTask<String, String, String> {

        HttpURLConnection conn;
        URL url = null;

        //this method will interact with UI, here display loading message
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        // This method does not interact with UI, You need to pass result to onPostExecute to display
        @Override
        protected String doInBackground(String... params) {
            try {
                String strURL = "http://cs-server.usc.edu:14345/sidPhp.php?ip=" + params[0] + "&type=" + params[1] + "&choice=details&temp=post&id="+ params[0];
                url = new URL(strURL);

            } catch (MalformedURLException e) {
                e.printStackTrace();
                return e.toString();
            }
            try {

                // Setup HttpURLConnection class to send and receive data from php
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(READ_TIMEOUT);
                conn.setConnectTimeout(CONNECTION_TIMEOUT);
                conn.setRequestMethod("GET");

                // setDoOutput to true as we recieve data from json file
                conn.setDoOutput(true);

            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
                return e1.toString();
            }
            try {

                int response_code = conn.getResponseCode();

                // Check if successful connection made
                if (response_code == HttpURLConnection.HTTP_OK) {

                    // Read data sent from server
                    InputStream input = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                    String line;

                    StringBuilder result = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }
                    // Pass data to onPostExecute method
                    return (result.toString());

                } else {

                    return ("unsuccessful");
                }

            } catch (IOException e) {
                e.printStackTrace();
                return e.toString();
            } finally {
                conn.disconnect();
            }

        }

        // this method will interact with UI, display result sent from doInBackground method
        @Override
        protected void onPostExecute(String result) {

            //textView.setText(result);

            if (result != null) // add this
            {

                try {

                    JSONArray new_array = new JSONArray(result);
                    for (int i = 0, count = new_array.length(); i < count; i++) {
                        try {

                            JSONObject jsonObject = new_array.getJSONObject(i);

                            time_array.add(jsonObject.getString("created_time"));
                            message_array.add(jsonObject.getString("message"));



                        } catch (JSONException e) {
                            e.printStackTrace();

                        }
                    }

                    adapter = new PostAdapter(getActivity(), time_array, message_array, name, url1);
                    list.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();


                }
            }

        }
    }
}