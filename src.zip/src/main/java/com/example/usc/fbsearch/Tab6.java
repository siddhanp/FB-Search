package com.example.usc.fbsearch;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;


public class Tab6 extends Fragment {
    public static final int CONNECTION_TIMEOUT = 10000;
    public static final int READ_TIMEOUT = 15000;
    private ListAdapterExpandible adapter;
    private ExpandableListView expListView;
    ArrayList<String> headersArrayList = new ArrayList<String>();
    HashMap<String, ArrayList<String>> childArrayList = new HashMap<String, ArrayList<String>>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        DetailsActivity god2 = new DetailsActivity();
        String s = god2.getCurrentId();
        View myInflatedView = inflater.inflate(R.layout.tab6, container, false);
        expListView = (ExpandableListView) myInflatedView.findViewById(R.id.expListView);
        new Tab6.AsyncRetrieve().execute(s, "user", "user");

        return myInflatedView;

    }

    private class AsyncRetrieve extends AsyncTask<String, String, String> {

        HttpURLConnection conn;
        URL url = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected String doInBackground(String... params) {
            try {
                String strURL = "http://cs-server.usc.edu:14345/sidPhp.php?ip=" + params[0] + "&type=" + params[1] + "&choice=details&temp=album&id="+ params[0];
                url = new URL(strURL);

            } catch (MalformedURLException e) {
                e.printStackTrace();
                return e.toString();
            }
            try {

                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(READ_TIMEOUT);
                conn.setConnectTimeout(CONNECTION_TIMEOUT);
                conn.setRequestMethod("GET");

                conn.setDoOutput(true);

            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
                return e1.toString();
            }
            try {

                int response_code = conn.getResponseCode();

                if (response_code == HttpURLConnection.HTTP_OK) {

                    InputStream input = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                    String line;

                    StringBuilder result = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }

                    return (result.toString());

                } else {

                    return ("unsuccessful");
                }

            } catch (IOException e) {
                e.printStackTrace();
                return e.toString();
            } finally {
                conn.disconnect();
            }

        }

        @Override
        protected void onPostExecute(String result) {

            if (result != null)
            {

                try {

                    JSONArray new_array = new JSONArray(result);
                    for (int i = 0, count = new_array.length(); i < count; i++) {
                        try {

                            // Get each object in array of objects
                            JSONObject album = new_array.getJSONObject(i);

                            // Get the name of each object in "name"
                            headersArrayList.add(album.getString("name"));

                            JSONObject photosObject = album.getJSONObject("photos");
                            JSONArray photosArray = photosObject.getJSONArray("data");

                            ArrayList<String> pictures = new ArrayList<String>();
                            for (int j = 0, count2 = photosArray.length(); j < count2; j++) {


                                JSONObject albumObject = photosArray.getJSONObject(j);
                                JSONArray imagesArray = albumObject.getJSONArray("images");

                                JSONObject images = imagesArray.getJSONObject(0);
                                pictures.add(images.getString("source"));

                            }

                            childArrayList.put(album.getString("name"), pictures);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    adapter = new ListAdapterExpandible(getActivity(), headersArrayList, childArrayList);
                    expListView.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();


                }
            }

        }
    }
}